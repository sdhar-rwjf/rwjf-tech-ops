

-- ************************************************************************************************
-- 4/5/2024 User Group Mapping INSERTS
-- ************************************************************************************************
REPLACE INTO uimp_departmentusergroups (Department,UserGroup) VALUES ('Foundation services','FS Only');
REPLACE INTO uimp_departmentusergroups (Department,UserGroup) VALUES ('Human Resources','HR Only');




