

-- ************************************************************************************************
-- 4/16/2024 Location Mapping INSERTS
-- ************************************************************************************************
REPLACE INTO uimp_locationmapping (Location,ReserveLocation) VALUES ('RWJF Main Campus','RWJF Princeton');
REPLACE INTO uimp_locationmapping (Location,ReserveLocation) VALUES ('RWJF New York City','RWJF New York');
REPLACE INTO uimp_locationmapping (Location,ReserveLocation) VALUES ('RWJF Washington, DC','RWJF Washington DC');




